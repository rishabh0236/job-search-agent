# Career Agent — Claude Code Instructions

Build a local-first AI Career Agent for a 2–5 person team.

Before modifying a subsystem, read its relevant skills/*.md file.

Core rules:
1. Candidate facts must be evidence-grounded.
2. Never fabricate resume/application information.
3. Human approval is mandatory before final submission.
4. Never bypass CAPTCHA, authentication, access controls, rate limits or site restrictions.
5. Prefer official/public APIs and permitted integrations.
6. Original resume/LaTeX remains immutable.
7. LLM outputs are proposals; deterministic code validates/applies them.
8. Important actions are auditable.
9. Optimize correctness/recoverability before scale.
10. Build mock integrations before real browser automation.

Target layout:
apps/web
apps/api
packages/schemas
packages/prompts
services/candidate
services/jobs
services/matching
services/resume
services/application
services/browser
tests
data
docs
scripts

Suggested commands:
make dev
make test
make lint
make format
make seed
make mock-site

When uncertain, stop safely and ask the user rather than guessing or submitting.
