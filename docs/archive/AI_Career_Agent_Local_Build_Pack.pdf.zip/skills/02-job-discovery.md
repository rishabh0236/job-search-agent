# Job Discovery
Implement a JobSource adapter:
search(criteria), fetch(job_id), normalize(raw_job), health_check().

Start with a small number of permitted/public ATS or company sources. Do not build universal scraping first.

Normalize: source, source_job_id, company, title, location, remote, employment_type, description, requirements, preferred, salary, url, posted_at, retrieved_at.

Deduplicate using source IDs, requisition IDs, canonical URLs, normalized company/title/location and description similarity. Store provenance.